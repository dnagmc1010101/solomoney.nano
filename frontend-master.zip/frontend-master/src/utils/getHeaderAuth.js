export function getHeaderAuth(token) {
	return `Bearer ${token}`;
}
